/********************************************************************************
** Form generated from reading UI file 'COOPViewer.ui'
**
** Created by: Qt User Interface Compiler version 5.14.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_COOPVIEWER_H
#define UI_COOPVIEWER_H

#include <COOPViewerWidget.h>
#include <QtCore/QDate>
#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QDateTimeEdit>
#include <QtWidgets/QDoubleSpinBox>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTableView>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_COOPViewerClass
{
public:
    QWidget *centralWidget;
    QVBoxLayout *verticalLayout_4;
    QHBoxLayout *horizontalLayout;
    COOPViewerWidget *openglWidget;
    QTabWidget *tabWidget;
    QWidget *tab;
    QVBoxLayout *verticalLayout;
    QGroupBox *groupBox;
    QHBoxLayout *horizontalLayout_2;
    QSpacerItem *horizontalSpacer;
    QPushButton *pushButton_load_prediction_command;
    QSpacerItem *horizontalSpacer_2;
    QGroupBox *groupBox_2;
    QVBoxLayout *verticalLayout_2;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label;
    QDateTimeEdit *dateTimeEdit_currTime;
    QPushButton *pushButton_go_to_time;
    QHBoxLayout *horizontalLayout_4;
    QPushButton *pushButton_go_to_start;
    QPushButton *pushButton_rewind;
    QPushButton *pushButton_play;
    QPushButton *pushButton_forward;
    QPushButton *pushButton_go_to_end;
    QHBoxLayout *horizontalLayout_5;
    QLabel *label_2;
    QSpinBox *spinBox_stepSize_hour;
    QSpinBox *spinBox_stepSize_min;
    QDoubleSpinBox *doubleSpinBox_stepSize_sec;
    QGroupBox *groupBox_3;
    QFormLayout *formLayout;
    QRadioButton *radioButton_selectPPDB;
    QRadioButton *radioButton_selectTPDB;
    QRadioButton *radioButton_selectSPDB;
    QRadioButton *radioButton_selectSafetyEval;
    QRadioButton *radioButton_selectCN;
    QSpacerItem *verticalSpacer_2;
    QGroupBox *ooiBox;
    QVBoxLayout *verticalLayout_3;
    QGroupBox *groupBox_5;
    QGridLayout *gridLayout_2;
    QLabel *label_3;
    QLineEdit *q1_distance;
    QLineEdit *q1_id;
    QPushButton *pushButton;
    QLabel *label_5;
    QGroupBox *groupBox_6;
    QGridLayout *gridLayout;
    QLineEdit *q2_distance;
    QPushButton *pushButton_2;
    QLabel *label_4;
    QGroupBox *q4Box;
    QGridLayout *gridLayout_4;
    QRadioButton *q4_n;
    QRadioButton *q4_c;
    QRadioButton *q4_b;
    QCheckBox *checkBox;
    QCheckBox *checkBox_2;
    QLabel *label_printStatus;
    QLabel *label_summary;
    QSpacerItem *verticalSpacer_3;
    QSpacerItem *verticalSpacer;
    QWidget *tab2;
    QVBoxLayout *verticalLayout_6;
    QTabWidget *tabWidget_2;
    QWidget *tab_3;
    QGridLayout *gridLayout_3;
    QTableView *tableView_TPDBData;
    QTableView *tableView_PPDBData;
    QLabel *label_6;
    QLabel *label_7;
    QWidget *tab_4;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *COOPViewerClass)
    {
        if (COOPViewerClass->objectName().isEmpty())
            COOPViewerClass->setObjectName(QString::fromUtf8("COOPViewerClass"));
        COOPViewerClass->resize(1131, 924);
        centralWidget = new QWidget(COOPViewerClass);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        verticalLayout_4 = new QVBoxLayout(centralWidget);
        verticalLayout_4->setSpacing(6);
        verticalLayout_4->setContentsMargins(11, 11, 11, 11);
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        openglWidget = new COOPViewerWidget(centralWidget);
        openglWidget->setObjectName(QString::fromUtf8("openglWidget"));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(openglWidget->sizePolicy().hasHeightForWidth());
        openglWidget->setSizePolicy(sizePolicy);
        openglWidget->setMinimumSize(QSize(200, 200));

        horizontalLayout->addWidget(openglWidget);

        tabWidget = new QTabWidget(centralWidget);
        tabWidget->setObjectName(QString::fromUtf8("tabWidget"));
        QSizePolicy sizePolicy1(QSizePolicy::Fixed, QSizePolicy::Expanding);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(tabWidget->sizePolicy().hasHeightForWidth());
        tabWidget->setSizePolicy(sizePolicy1);
        tabWidget->setMinimumSize(QSize(400, 0));
        tabWidget->setTabBarAutoHide(false);
        tab = new QWidget();
        tab->setObjectName(QString::fromUtf8("tab"));
        verticalLayout = new QVBoxLayout(tab);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        groupBox = new QGroupBox(tab);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        horizontalLayout_2 = new QHBoxLayout(groupBox);
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalSpacer = new QSpacerItem(50, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer);

        pushButton_load_prediction_command = new QPushButton(groupBox);
        pushButton_load_prediction_command->setObjectName(QString::fromUtf8("pushButton_load_prediction_command"));

        horizontalLayout_2->addWidget(pushButton_load_prediction_command);

        horizontalSpacer_2 = new QSpacerItem(50, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_2);


        verticalLayout->addWidget(groupBox);

        groupBox_2 = new QGroupBox(tab);
        groupBox_2->setObjectName(QString::fromUtf8("groupBox_2"));
        verticalLayout_2 = new QVBoxLayout(groupBox_2);
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setContentsMargins(11, 11, 11, 11);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setSpacing(6);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        label = new QLabel(groupBox_2);
        label->setObjectName(QString::fromUtf8("label"));
        label->setMaximumSize(QSize(50, 16777215));
        label->setAlignment(Qt::AlignCenter);

        horizontalLayout_3->addWidget(label);

        dateTimeEdit_currTime = new QDateTimeEdit(groupBox_2);
        dateTimeEdit_currTime->setObjectName(QString::fromUtf8("dateTimeEdit_currTime"));
        dateTimeEdit_currTime->setAlignment(Qt::AlignCenter);
        dateTimeEdit_currTime->setDateTime(QDateTime(QDate(2021, 3, 6), QTime(0, 0, 0)));
        dateTimeEdit_currTime->setDate(QDate(2021, 3, 6));

        horizontalLayout_3->addWidget(dateTimeEdit_currTime);

        pushButton_go_to_time = new QPushButton(groupBox_2);
        pushButton_go_to_time->setObjectName(QString::fromUtf8("pushButton_go_to_time"));
        pushButton_go_to_time->setMaximumSize(QSize(30, 16777215));

        horizontalLayout_3->addWidget(pushButton_go_to_time);


        verticalLayout_2->addLayout(horizontalLayout_3);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setSpacing(6);
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        pushButton_go_to_start = new QPushButton(groupBox_2);
        pushButton_go_to_start->setObjectName(QString::fromUtf8("pushButton_go_to_start"));
        pushButton_go_to_start->setMaximumSize(QSize(40, 16777215));

        horizontalLayout_4->addWidget(pushButton_go_to_start);

        pushButton_rewind = new QPushButton(groupBox_2);
        pushButton_rewind->setObjectName(QString::fromUtf8("pushButton_rewind"));
        pushButton_rewind->setMaximumSize(QSize(40, 16777215));

        horizontalLayout_4->addWidget(pushButton_rewind);

        pushButton_play = new QPushButton(groupBox_2);
        pushButton_play->setObjectName(QString::fromUtf8("pushButton_play"));
        pushButton_play->setMaximumSize(QSize(50, 16777215));

        horizontalLayout_4->addWidget(pushButton_play);

        pushButton_forward = new QPushButton(groupBox_2);
        pushButton_forward->setObjectName(QString::fromUtf8("pushButton_forward"));
        pushButton_forward->setMaximumSize(QSize(40, 16777215));

        horizontalLayout_4->addWidget(pushButton_forward);

        pushButton_go_to_end = new QPushButton(groupBox_2);
        pushButton_go_to_end->setObjectName(QString::fromUtf8("pushButton_go_to_end"));
        pushButton_go_to_end->setMaximumSize(QSize(40, 16777215));

        horizontalLayout_4->addWidget(pushButton_go_to_end);


        verticalLayout_2->addLayout(horizontalLayout_4);

        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setSpacing(6);
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        label_2 = new QLabel(groupBox_2);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setAlignment(Qt::AlignCenter);

        horizontalLayout_5->addWidget(label_2);

        spinBox_stepSize_hour = new QSpinBox(groupBox_2);
        spinBox_stepSize_hour->setObjectName(QString::fromUtf8("spinBox_stepSize_hour"));
        spinBox_stepSize_hour->setMaximumSize(QSize(50, 16777215));
        spinBox_stepSize_hour->setAlignment(Qt::AlignCenter);
        spinBox_stepSize_hour->setMaximum(24);

        horizontalLayout_5->addWidget(spinBox_stepSize_hour);

        spinBox_stepSize_min = new QSpinBox(groupBox_2);
        spinBox_stepSize_min->setObjectName(QString::fromUtf8("spinBox_stepSize_min"));
        spinBox_stepSize_min->setMaximumSize(QSize(50, 16777215));
        spinBox_stepSize_min->setAlignment(Qt::AlignCenter);

        horizontalLayout_5->addWidget(spinBox_stepSize_min);

        doubleSpinBox_stepSize_sec = new QDoubleSpinBox(groupBox_2);
        doubleSpinBox_stepSize_sec->setObjectName(QString::fromUtf8("doubleSpinBox_stepSize_sec"));
        doubleSpinBox_stepSize_sec->setMaximumSize(QSize(50, 16777215));
        doubleSpinBox_stepSize_sec->setDecimals(1);
        doubleSpinBox_stepSize_sec->setMinimum(0.100000000000000);
        doubleSpinBox_stepSize_sec->setValue(10.000000000000000);

        horizontalLayout_5->addWidget(doubleSpinBox_stepSize_sec);


        verticalLayout_2->addLayout(horizontalLayout_5);


        verticalLayout->addWidget(groupBox_2);

        groupBox_3 = new QGroupBox(tab);
        groupBox_3->setObjectName(QString::fromUtf8("groupBox_3"));
        formLayout = new QFormLayout(groupBox_3);
        formLayout->setSpacing(6);
        formLayout->setContentsMargins(11, 11, 11, 11);
        formLayout->setObjectName(QString::fromUtf8("formLayout"));
        radioButton_selectPPDB = new QRadioButton(groupBox_3);
        radioButton_selectPPDB->setObjectName(QString::fromUtf8("radioButton_selectPPDB"));
        radioButton_selectPPDB->setChecked(true);

        formLayout->setWidget(0, QFormLayout::LabelRole, radioButton_selectPPDB);

        radioButton_selectTPDB = new QRadioButton(groupBox_3);
        radioButton_selectTPDB->setObjectName(QString::fromUtf8("radioButton_selectTPDB"));

        formLayout->setWidget(0, QFormLayout::FieldRole, radioButton_selectTPDB);

        radioButton_selectSPDB = new QRadioButton(groupBox_3);
        radioButton_selectSPDB->setObjectName(QString::fromUtf8("radioButton_selectSPDB"));

        formLayout->setWidget(1, QFormLayout::LabelRole, radioButton_selectSPDB);

        radioButton_selectSafetyEval = new QRadioButton(groupBox_3);
        radioButton_selectSafetyEval->setObjectName(QString::fromUtf8("radioButton_selectSafetyEval"));

        formLayout->setWidget(1, QFormLayout::FieldRole, radioButton_selectSafetyEval);

        radioButton_selectCN = new QRadioButton(groupBox_3);
        radioButton_selectCN->setObjectName(QString::fromUtf8("radioButton_selectCN"));

        formLayout->setWidget(2, QFormLayout::LabelRole, radioButton_selectCN);


        verticalLayout->addWidget(groupBox_3);

        verticalSpacer_2 = new QSpacerItem(20, 10, QSizePolicy::Minimum, QSizePolicy::Fixed);

        verticalLayout->addItem(verticalSpacer_2);

        ooiBox = new QGroupBox(tab);
        ooiBox->setObjectName(QString::fromUtf8("ooiBox"));
        verticalLayout_3 = new QVBoxLayout(ooiBox);
        verticalLayout_3->setSpacing(6);
        verticalLayout_3->setContentsMargins(11, 11, 11, 11);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        groupBox_5 = new QGroupBox(ooiBox);
        groupBox_5->setObjectName(QString::fromUtf8("groupBox_5"));
        gridLayout_2 = new QGridLayout(groupBox_5);
        gridLayout_2->setSpacing(6);
        gridLayout_2->setContentsMargins(11, 11, 11, 11);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        label_3 = new QLabel(groupBox_5);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        gridLayout_2->addWidget(label_3, 0, 0, 1, 1);

        q1_distance = new QLineEdit(groupBox_5);
        q1_distance->setObjectName(QString::fromUtf8("q1_distance"));

        gridLayout_2->addWidget(q1_distance, 3, 0, 1, 1);

        q1_id = new QLineEdit(groupBox_5);
        q1_id->setObjectName(QString::fromUtf8("q1_id"));

        gridLayout_2->addWidget(q1_id, 1, 0, 1, 1);

        pushButton = new QPushButton(groupBox_5);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));

        gridLayout_2->addWidget(pushButton, 3, 1, 1, 1);

        label_5 = new QLabel(groupBox_5);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        gridLayout_2->addWidget(label_5, 2, 0, 1, 1);


        verticalLayout_3->addWidget(groupBox_5);

        groupBox_6 = new QGroupBox(ooiBox);
        groupBox_6->setObjectName(QString::fromUtf8("groupBox_6"));
        gridLayout = new QGridLayout(groupBox_6);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        q2_distance = new QLineEdit(groupBox_6);
        q2_distance->setObjectName(QString::fromUtf8("q2_distance"));

        gridLayout->addWidget(q2_distance, 1, 0, 1, 1);

        pushButton_2 = new QPushButton(groupBox_6);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));

        gridLayout->addWidget(pushButton_2, 1, 1, 1, 1);

        label_4 = new QLabel(groupBox_6);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        gridLayout->addWidget(label_4, 0, 0, 1, 1);


        verticalLayout_3->addWidget(groupBox_6);


        verticalLayout->addWidget(ooiBox);

        q4Box = new QGroupBox(tab);
        q4Box->setObjectName(QString::fromUtf8("q4Box"));
        gridLayout_4 = new QGridLayout(q4Box);
        gridLayout_4->setSpacing(6);
        gridLayout_4->setContentsMargins(11, 11, 11, 11);
        gridLayout_4->setObjectName(QString::fromUtf8("gridLayout_4"));
        q4_n = new QRadioButton(q4Box);
        q4_n->setObjectName(QString::fromUtf8("q4_n"));
        q4_n->setChecked(true);

        gridLayout_4->addWidget(q4_n, 0, 1, 1, 1);

        q4_c = new QRadioButton(q4Box);
        q4_c->setObjectName(QString::fromUtf8("q4_c"));

        gridLayout_4->addWidget(q4_c, 0, 3, 1, 1);

        q4_b = new QRadioButton(q4Box);
        q4_b->setObjectName(QString::fromUtf8("q4_b"));

        gridLayout_4->addWidget(q4_b, 0, 2, 1, 1);

        checkBox = new QCheckBox(q4Box);
        checkBox->setObjectName(QString::fromUtf8("checkBox"));
        checkBox->setChecked(true);

        gridLayout_4->addWidget(checkBox, 1, 1, 1, 1);

        checkBox_2 = new QCheckBox(q4Box);
        checkBox_2->setObjectName(QString::fromUtf8("checkBox_2"));
        checkBox_2->setChecked(true);

        gridLayout_4->addWidget(checkBox_2, 1, 2, 1, 1);


        verticalLayout->addWidget(q4Box);

        label_printStatus = new QLabel(tab);
        label_printStatus->setObjectName(QString::fromUtf8("label_printStatus"));
        QSizePolicy sizePolicy2(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(label_printStatus->sizePolicy().hasHeightForWidth());
        label_printStatus->setSizePolicy(sizePolicy2);
        label_printStatus->setMinimumSize(QSize(400, 10));
        label_printStatus->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);

        verticalLayout->addWidget(label_printStatus);

        label_summary = new QLabel(tab);
        label_summary->setObjectName(QString::fromUtf8("label_summary"));
        sizePolicy.setHeightForWidth(label_summary->sizePolicy().hasHeightForWidth());
        label_summary->setSizePolicy(sizePolicy);

        verticalLayout->addWidget(label_summary);

        verticalSpacer_3 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer_3);

        verticalSpacer = new QSpacerItem(20, 10, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer);

        tabWidget->addTab(tab, QString());
        tab2 = new QWidget();
        tab2->setObjectName(QString::fromUtf8("tab2"));
        verticalLayout_6 = new QVBoxLayout(tab2);
        verticalLayout_6->setSpacing(6);
        verticalLayout_6->setContentsMargins(11, 11, 11, 11);
        verticalLayout_6->setObjectName(QString::fromUtf8("verticalLayout_6"));
        tabWidget->addTab(tab2, QString());

        horizontalLayout->addWidget(tabWidget);


        verticalLayout_4->addLayout(horizontalLayout);

        tabWidget_2 = new QTabWidget(centralWidget);
        tabWidget_2->setObjectName(QString::fromUtf8("tabWidget_2"));
        QSizePolicy sizePolicy3(QSizePolicy::Preferred, QSizePolicy::Expanding);
        sizePolicy3.setHorizontalStretch(0);
        sizePolicy3.setVerticalStretch(0);
        sizePolicy3.setHeightForWidth(tabWidget_2->sizePolicy().hasHeightForWidth());
        tabWidget_2->setSizePolicy(sizePolicy3);
        tabWidget_2->setMinimumSize(QSize(0, 50));
        tabWidget_2->setMaximumSize(QSize(16777215, 200));
        tab_3 = new QWidget();
        tab_3->setObjectName(QString::fromUtf8("tab_3"));
        gridLayout_3 = new QGridLayout(tab_3);
        gridLayout_3->setSpacing(6);
        gridLayout_3->setContentsMargins(11, 11, 11, 11);
        gridLayout_3->setObjectName(QString::fromUtf8("gridLayout_3"));
        tableView_TPDBData = new QTableView(tab_3);
        tableView_TPDBData->setObjectName(QString::fromUtf8("tableView_TPDBData"));

        gridLayout_3->addWidget(tableView_TPDBData, 1, 2, 1, 1);

        tableView_PPDBData = new QTableView(tab_3);
        tableView_PPDBData->setObjectName(QString::fromUtf8("tableView_PPDBData"));
        QSizePolicy sizePolicy4(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy4.setHorizontalStretch(0);
        sizePolicy4.setVerticalStretch(0);
        sizePolicy4.setHeightForWidth(tableView_PPDBData->sizePolicy().hasHeightForWidth());
        tableView_PPDBData->setSizePolicy(sizePolicy4);
        tableView_PPDBData->verticalHeader()->setProperty("showSortIndicator", QVariant(true));

        gridLayout_3->addWidget(tableView_PPDBData, 1, 1, 1, 1);

        label_6 = new QLabel(tab_3);
        label_6->setObjectName(QString::fromUtf8("label_6"));

        gridLayout_3->addWidget(label_6, 0, 1, 1, 1);

        label_7 = new QLabel(tab_3);
        label_7->setObjectName(QString::fromUtf8("label_7"));

        gridLayout_3->addWidget(label_7, 0, 2, 1, 1);

        tabWidget_2->addTab(tab_3, QString());
        tab_4 = new QWidget();
        tab_4->setObjectName(QString::fromUtf8("tab_4"));
        tabWidget_2->addTab(tab_4, QString());

        verticalLayout_4->addWidget(tabWidget_2);

        COOPViewerClass->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(COOPViewerClass);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 1131, 21));
        COOPViewerClass->setMenuBar(menuBar);
        mainToolBar = new QToolBar(COOPViewerClass);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        COOPViewerClass->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(COOPViewerClass);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        COOPViewerClass->setStatusBar(statusBar);

        retranslateUi(COOPViewerClass);
        QObject::connect(pushButton_load_prediction_command, SIGNAL(clicked()), COOPViewerClass, SLOT(load_prediction_command()));
        QObject::connect(pushButton_play, SIGNAL(clicked()), COOPViewerClass, SLOT(play_simulation()));
        QObject::connect(spinBox_stepSize_hour, SIGNAL(valueChanged(int)), COOPViewerClass, SLOT(time_step_changed()));
        QObject::connect(spinBox_stepSize_min, SIGNAL(valueChanged(int)), COOPViewerClass, SLOT(time_step_changed()));
        QObject::connect(doubleSpinBox_stepSize_sec, SIGNAL(valueChanged(double)), COOPViewerClass, SLOT(time_step_changed()));
        QObject::connect(pushButton_forward, SIGNAL(clicked()), COOPViewerClass, SLOT(increase_time_by_step()));
        QObject::connect(pushButton_rewind, SIGNAL(clicked()), COOPViewerClass, SLOT(decrease_time_by_step()));
        QObject::connect(pushButton_go_to_start, SIGNAL(clicked()), COOPViewerClass, SLOT(go_to_start_moment()));
        QObject::connect(pushButton_go_to_end, SIGNAL(clicked()), COOPViewerClass, SLOT(go_to_end_moment()));
        QObject::connect(radioButton_selectPPDB, SIGNAL(clicked()), COOPViewerClass, SLOT(mode_selection_changed()));
        QObject::connect(radioButton_selectTPDB, SIGNAL(clicked()), COOPViewerClass, SLOT(mode_selection_changed()));
        QObject::connect(radioButton_selectSPDB, SIGNAL(clicked()), COOPViewerClass, SLOT(mode_selection_changed()));
        QObject::connect(radioButton_selectSafetyEval, SIGNAL(clicked()), COOPViewerClass, SLOT(mode_selection_changed()));
        QObject::connect(tableView_PPDBData, SIGNAL(doubleClicked(QModelIndex)), COOPViewerClass, SLOT(update_PPDB_selection_in_table(QModelIndex)));
        QObject::connect(tableView_TPDBData, SIGNAL(doubleClicked(QModelIndex)), COOPViewerClass, SLOT(update_TPDB_selection_in_table(QModelIndex)));
        QObject::connect(pushButton, SIGNAL(clicked()), COOPViewerClass, SLOT(objectOfInterest_changed()));
        QObject::connect(pushButton_2, SIGNAL(clicked()), COOPViewerClass, SLOT(objectOfInterest_changed()));
        QObject::connect(pushButton, SIGNAL(clicked()), COOPViewerClass, SLOT(update_PPDB_n_TPDB_table_Q1()));
        QObject::connect(pushButton_2, SIGNAL(clicked()), COOPViewerClass, SLOT(update_PPDB_n_TPDB_table_Q2()));
        QObject::connect(q4_n, SIGNAL(clicked()), COOPViewerClass, SLOT(space_center_selection_changed_Q4()));
        QObject::connect(q4_b, SIGNAL(clicked()), COOPViewerClass, SLOT(space_center_selection_changed_Q4()));
        QObject::connect(q4_c, SIGNAL(clicked()), COOPViewerClass, SLOT(space_center_selection_changed_Q4()));
        QObject::connect(radioButton_selectCN, SIGNAL(clicked()), COOPViewerClass, SLOT(mode_selection_changed()));
        QObject::connect(checkBox, SIGNAL(clicked()), COOPViewerClass, SLOT(on_all_RSOs()));
        QObject::connect(checkBox_2, SIGNAL(clicked()), COOPViewerClass, SLOT(on_ciritical_RSOs()));

        tabWidget->setCurrentIndex(0);
        tabWidget_2->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(COOPViewerClass);
    } // setupUi

    void retranslateUi(QMainWindow *COOPViewerClass)
    {
        COOPViewerClass->setWindowTitle(QCoreApplication::translate("COOPViewerClass", "COOPViewer", nullptr));
        groupBox->setTitle(QCoreApplication::translate("COOPViewerClass", "Load Files", nullptr));
        pushButton_load_prediction_command->setText(QCoreApplication::translate("COOPViewerClass", "1. Load Results", nullptr));
        groupBox_2->setTitle(QCoreApplication::translate("COOPViewerClass", "Control", nullptr));
        label->setText(QCoreApplication::translate("COOPViewerClass", "Time", nullptr));
        dateTimeEdit_currTime->setDisplayFormat(QCoreApplication::translate("COOPViewerClass", "MM-dd-yyyy hh:mm:ss", nullptr));
        pushButton_go_to_time->setText(QCoreApplication::translate("COOPViewerClass", "Go", nullptr));
        pushButton_go_to_start->setText(QCoreApplication::translate("COOPViewerClass", "|\342\227\200", nullptr));
        pushButton_rewind->setText(QCoreApplication::translate("COOPViewerClass", "\342\227\200\342\227\200", nullptr));
        pushButton_play->setText(QCoreApplication::translate("COOPViewerClass", "\342\226\266/||", nullptr));
        pushButton_forward->setText(QCoreApplication::translate("COOPViewerClass", "\342\226\266\342\226\266", nullptr));
        pushButton_go_to_end->setText(QCoreApplication::translate("COOPViewerClass", "\342\226\266|", nullptr));
        label_2->setText(QCoreApplication::translate("COOPViewerClass", "Play speed", nullptr));
        spinBox_stepSize_hour->setSuffix(QCoreApplication::translate("COOPViewerClass", " h", nullptr));
        spinBox_stepSize_min->setSuffix(QCoreApplication::translate("COOPViewerClass", " m", nullptr));
        doubleSpinBox_stepSize_sec->setSuffix(QCoreApplication::translate("COOPViewerClass", " s", nullptr));
        groupBox_3->setTitle(QCoreApplication::translate("COOPViewerClass", "COOP Queries", nullptr));
        radioButton_selectPPDB->setText(QCoreApplication::translate("COOPViewerClass", "PPDB", nullptr));
        radioButton_selectTPDB->setText(QCoreApplication::translate("COOPViewerClass", "TPDB", nullptr));
        radioButton_selectSPDB->setText(QCoreApplication::translate("COOPViewerClass", "Q3 [Shortest Path]", nullptr));
        radioButton_selectSafetyEval->setText(QCoreApplication::translate("COOPViewerClass", "Q4 [Safety Evaluation]", nullptr));
        radioButton_selectCN->setText(QCoreApplication::translate("COOPViewerClass", "Q* [Closest Neighbors]", nullptr));
        ooiBox->setTitle(QCoreApplication::translate("COOPViewerClass", "Object of Interest", nullptr));
        groupBox_5->setTitle(QCoreApplication::translate("COOPViewerClass", "Q1.", nullptr));
        label_3->setText(QCoreApplication::translate("COOPViewerClass", "Catalog ID", nullptr));
        pushButton->setText(QCoreApplication::translate("COOPViewerClass", "Submit", nullptr));
        label_5->setText(QCoreApplication::translate("COOPViewerClass", "Cut Off Distance (km)", nullptr));
        groupBox_6->setTitle(QCoreApplication::translate("COOPViewerClass", "Q2.", nullptr));
        pushButton_2->setText(QCoreApplication::translate("COOPViewerClass", "Submit", nullptr));
        label_4->setText(QCoreApplication::translate("COOPViewerClass", "Cut Off Distance (km)", nullptr));
        q4Box->setTitle(QCoreApplication::translate("COOPViewerClass", "Q4. [Select Space Center]", nullptr));
        q4_n->setText(QCoreApplication::translate("COOPViewerClass", "\353\202\230\353\241\234 \354\232\260\354\243\274\354\204\274\355\204\260", nullptr));
        q4_c->setText(QCoreApplication::translate("COOPViewerClass", "Cape Canaveral", nullptr));
        q4_b->setText(QCoreApplication::translate("COOPViewerClass", "Boca Chica", nullptr));
        checkBox->setText(QCoreApplication::translate("COOPViewerClass", "All RSOs", nullptr));
        checkBox_2->setText(QCoreApplication::translate("COOPViewerClass", "Critical RSOs", nullptr));
        label_printStatus->setText(QCoreApplication::translate("COOPViewerClass", "Welcome to COOP Program.", nullptr));
        label_summary->setText(QString());
        tabWidget->setTabText(tabWidget->indexOf(tab), QCoreApplication::translate("COOPViewerClass", "Viewer Controller", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab2), QCoreApplication::translate("COOPViewerClass", "Tab 2", nullptr));
        label_6->setText(QCoreApplication::translate("COOPViewerClass", "PPDB", nullptr));
        label_7->setText(QCoreApplication::translate("COOPViewerClass", "TPDB", nullptr));
        tabWidget_2->setTabText(tabWidget_2->indexOf(tab_3), QCoreApplication::translate("COOPViewerClass", "PPDB & TPDB Data", nullptr));
        tabWidget_2->setTabText(tabWidget_2->indexOf(tab_4), QCoreApplication::translate("COOPViewerClass", "Tab 2", nullptr));
    } // retranslateUi

};

namespace Ui {
    class COOPViewerClass: public Ui_COOPViewerClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_COOPVIEWER_H
