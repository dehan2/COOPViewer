/****************************************************************************
** Meta object code from reading C++ file 'COOPViewer.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.14.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../../COOPViewer.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'COOPViewer.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.14.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_COOPViewer_t {
    QByteArrayData data[25];
    char stringdata0[485];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_COOPViewer_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_COOPViewer_t qt_meta_stringdata_COOPViewer = {
    {
QT_MOC_LITERAL(0, 0, 10), // "COOPViewer"
QT_MOC_LITERAL(1, 11, 23), // "load_prediction_command"
QT_MOC_LITERAL(2, 35, 0), // ""
QT_MOC_LITERAL(3, 36, 14), // "load_PPDB_file"
QT_MOC_LITERAL(4, 51, 14), // "load_TPDB_file"
QT_MOC_LITERAL(5, 66, 15), // "play_simulation"
QT_MOC_LITERAL(6, 82, 13), // "load_starlink"
QT_MOC_LITERAL(7, 96, 18), // "load_shortest_link"
QT_MOC_LITERAL(8, 115, 17), // "load_orbit_tunnel"
QT_MOC_LITERAL(9, 133, 24), // "increase_simulation_time"
QT_MOC_LITERAL(10, 158, 17), // "time_step_changed"
QT_MOC_LITERAL(11, 176, 21), // "increase_time_by_step"
QT_MOC_LITERAL(12, 198, 21), // "decrease_time_by_step"
QT_MOC_LITERAL(13, 220, 18), // "go_to_start_moment"
QT_MOC_LITERAL(14, 239, 16), // "go_to_end_moment"
QT_MOC_LITERAL(15, 256, 30), // "update_PPDB_selection_in_table"
QT_MOC_LITERAL(16, 287, 11), // "QModelIndex"
QT_MOC_LITERAL(17, 299, 11), // "selectedRow"
QT_MOC_LITERAL(18, 311, 30), // "update_TPDB_selection_in_table"
QT_MOC_LITERAL(19, 342, 22), // "mode_selection_changed"
QT_MOC_LITERAL(20, 365, 33), // "space_center_selection_change..."
QT_MOC_LITERAL(21, 399, 27), // "update_PPDB_n_TPDB_table_Q1"
QT_MOC_LITERAL(22, 427, 27), // "update_PPDB_n_TPDB_table_Q2"
QT_MOC_LITERAL(23, 455, 11), // "on_all_RSOs"
QT_MOC_LITERAL(24, 467, 17) // "on_criticial_RSOs"

    },
    "COOPViewer\0load_prediction_command\0\0"
    "load_PPDB_file\0load_TPDB_file\0"
    "play_simulation\0load_starlink\0"
    "load_shortest_link\0load_orbit_tunnel\0"
    "increase_simulation_time\0time_step_changed\0"
    "increase_time_by_step\0decrease_time_by_step\0"
    "go_to_start_moment\0go_to_end_moment\0"
    "update_PPDB_selection_in_table\0"
    "QModelIndex\0selectedRow\0"
    "update_TPDB_selection_in_table\0"
    "mode_selection_changed\0"
    "space_center_selection_changed_Q4\0"
    "update_PPDB_n_TPDB_table_Q1\0"
    "update_PPDB_n_TPDB_table_Q2\0on_all_RSOs\0"
    "on_criticial_RSOs"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_COOPViewer[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      21,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  119,    2, 0x0a /* Public */,
       3,    0,  120,    2, 0x0a /* Public */,
       4,    0,  121,    2, 0x0a /* Public */,
       5,    0,  122,    2, 0x0a /* Public */,
       6,    0,  123,    2, 0x0a /* Public */,
       7,    0,  124,    2, 0x0a /* Public */,
       8,    0,  125,    2, 0x0a /* Public */,
       9,    0,  126,    2, 0x0a /* Public */,
      10,    0,  127,    2, 0x0a /* Public */,
      11,    0,  128,    2, 0x0a /* Public */,
      12,    0,  129,    2, 0x0a /* Public */,
      13,    0,  130,    2, 0x0a /* Public */,
      14,    0,  131,    2, 0x0a /* Public */,
      15,    1,  132,    2, 0x0a /* Public */,
      18,    1,  135,    2, 0x0a /* Public */,
      19,    0,  138,    2, 0x0a /* Public */,
      20,    0,  139,    2, 0x0a /* Public */,
      21,    0,  140,    2, 0x0a /* Public */,
      22,    0,  141,    2, 0x0a /* Public */,
      23,    0,  142,    2, 0x0a /* Public */,
      24,    0,  143,    2, 0x0a /* Public */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 16,   17,
    QMetaType::Void, 0x80000000 | 16,   17,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void COOPViewer::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<COOPViewer *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->load_prediction_command(); break;
        case 1: _t->load_PPDB_file(); break;
        case 2: _t->load_TPDB_file(); break;
        case 3: _t->play_simulation(); break;
        case 4: _t->load_starlink(); break;
        case 5: _t->load_shortest_link(); break;
        case 6: _t->load_orbit_tunnel(); break;
        case 7: _t->increase_simulation_time(); break;
        case 8: _t->time_step_changed(); break;
        case 9: _t->increase_time_by_step(); break;
        case 10: _t->decrease_time_by_step(); break;
        case 11: _t->go_to_start_moment(); break;
        case 12: _t->go_to_end_moment(); break;
        case 13: _t->update_PPDB_selection_in_table((*reinterpret_cast< QModelIndex(*)>(_a[1]))); break;
        case 14: _t->update_TPDB_selection_in_table((*reinterpret_cast< QModelIndex(*)>(_a[1]))); break;
        case 15: _t->mode_selection_changed(); break;
        case 16: _t->space_center_selection_changed_Q4(); break;
        case 17: _t->update_PPDB_n_TPDB_table_Q1(); break;
        case 18: _t->update_PPDB_n_TPDB_table_Q2(); break;
        case 19: _t->on_all_RSOs(); break;
        case 20: _t->on_criticial_RSOs(); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject COOPViewer::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_COOPViewer.data,
    qt_meta_data_COOPViewer,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *COOPViewer::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *COOPViewer::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_COOPViewer.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int COOPViewer::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 21)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 21;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 21)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 21;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
